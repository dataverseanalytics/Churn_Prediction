# Membership Churn Prediction System

A comprehensive ML-based system for predicting membership churn and renewal risk. Combines rule-based risk assessment with machine learning predictions.

## Features

✅ **ML Churn Prediction** - Train models on 440K+ membership records  
✅ **Rule-Based Risk Assessment** - Configurable weighted scoring system  
✅ **Dual Prediction Modes** - Toggle between ML and rule-based approaches  
✅ **Feature Engineering** - Automated feature creation and preprocessing  
✅ **Model Comparison** - Evaluates Logistic Regression, Random Forest, and Gradient Boosting  
✅ **FastAPI Backend** - High-performance async API with automatic documentation  
✅ **Modern UI** - Beautiful, responsive interface with visualizations  

## Requirements

- Python 3.8 or higher
- Modern web browser (Chrome, Firefox, Edge, Safari)

## Installation

### 1. Activate Virtual Environment

```powershell
.\env\Scripts\activate.bat
```

### 2. Install Dependencies

```powershell
pip install -r requirements.txt
```

## Usage

### Step 1: Train the ML Model

Before using ML predictions, train the model on the membership churn dataset:

```powershell
python model_trainer.py
```

This will:
- Load 440K+ training records
- Engineer features (tenure categories, usage patterns, etc.)
- Train multiple ML models (Logistic Regression, Random Forest, Gradient Boosting)
- Evaluate and select the best model
- Save the trained model to `models/` directory

**Expected output:**
- Model accuracy, precision, recall, F1-score, ROC-AUC
- Confusion matrix
- Cross-validation scores
- Saved model files in `models/` directory

### Step 2: Start the Application

```powershell
python app.py
```

The application will start on `http://localhost:8000`

### Step 3: Access the System

1. **Web Interface**: Open your browser to `http://localhost:8000`
2. **API Documentation**: Visit `http://localhost:8000/docs` for interactive API docs

## Prediction Modes

### ML-Based Churn Prediction

Uses trained machine learning model to predict churn probability (0-100%).

**Features used:**
- Age, Gender, Tenure
- Usage Frequency
- Support Calls
- Payment Delay
- Subscription Type
- Contract Length
- Total Spend
- Last Interaction

**Risk Categories:**
- **Low Risk (≤30%)**: Member unlikely to churn
- **Medium Risk (31-60%)**: Member needs attention
- **High Risk (≥61%)**: Member at serious risk of churning

### Rule-Based Risk Assessment

Configurable weighted scoring based on member attributes:
- Committee participation
- Membership history
- Meeting attendance
- Purchase history
- Donation activity
- Years of practicing
- Previous lapse status
- Website activity

## API Endpoints

### ML Endpoints

- `POST /api/ml/predict-churn` - Get ML churn predictions
- `GET /api/ml/feature-importance` - View top features influencing predictions
- `GET /api/ml/status` - Check if ML model is loaded

### Rule-Based Endpoints

- `GET /api/members` - Get all members needing assessment
- `GET /api/attributes` - Get available attributes and weights
- `POST /api/calculate-risk` - Calculate risk with custom weights
- `GET /api/member/{member_id}` - Get detailed member information

### General

- `GET /api/test` - Test API connectivity

## Project Structure

```
├── app.py                          # FastAPI backend
├── model_trainer.py                # ML model training script
├── ml_model.py                     # ML prediction module
├── data_processor.py               # Data loading and preprocessing
├── risk_calculator.py              # Rule-based risk scoring
├── requirements.txt                # Python dependencies
├── README.md                       # Documentation
├── models/                         # Trained ML models (created after training)
│   ├── churn_model.pkl
│   ├── scaler.pkl
│   ├── label_encoders.pkl
│   └── feature_columns.pkl
├── static/
│   ├── index.html                  # Main web interface
│   ├── css/
│   │   └── style.css              # Styling
│   └── js/
│       └── app.js                  # Frontend logic
├── archive membership from Kaggle/
│   ├── customer_churn_dataset-training-master.csv  # 440K training records
│   └── customer_churn_dataset-testing-master.csv   # Test dataset
├── membership-records from Gomask.csv
└── subscription-billing from GoMask.csv
```

## ML Model Details

### Training Dataset
- **Size**: 440,835 records
- **Features**: 11 core features + 7 engineered features
- **Target**: Binary churn (0 = retained, 1 = churned)

### Feature Engineering
- Tenure categories (0-12, 13-24, 25-36, 37-48, 49+ months)
- Usage categories (Low, Medium, High)
- Payment delay severity
- Spend per month
- Support call rate
- Interaction recency
- Age groups

### Models Evaluated
1. **Logistic Regression** - Baseline linear model
2. **Random Forest** - Ensemble decision trees
3. **Gradient Boosting** - Advanced boosting algorithm

### Evaluation Metrics
- Accuracy
- Precision, Recall, F1-Score
- ROC-AUC (primary metric for model selection)
- 5-fold Cross-Validation

## Troubleshooting

### ML Model Not Available

If you see "ML model not available" error:
```powershell
python model_trainer.py
```

### Dependencies Won't Install

```powershell
pip install --upgrade pip
pip install -r requirements.txt
```

### Port Already in Use

Edit `app.py` and change the port:
```python
uvicorn.run(app, host="0.0.0.0", port=8001)  # Change to any available port
```

## Technical Stack

- **Backend**: FastAPI with async endpoints
- **ML**: scikit-learn (Random Forest, Gradient Boosting, Logistic Regression)
- **Data Processing**: Pandas, NumPy
- **Frontend**: Vanilla JavaScript with Chart.js
- **Styling**: Modern CSS with gradients and glassmorphism

## License

This project is for internal use in membership management.

## Support

For issues or questions:
1. Check the API documentation at `/docs`
2. Review model training output
3. Verify all dependencies are installed
#   C h u r n _ P r e d i c t i o n  
 